@AGENTS.md

## Approved Hero Typography Direction

The BZABIK.ART hero uses an oversized editorial display treatment for the main title:

- `DIGITAL / CREATIVE / ARCHIVE` is intentionally very large and left-led.
- Display face: `Space Grotesk`.
- Weight: approximately `500` (medium, not bold).
- Tight tracking and compact line-height create the oversized editorial character.
- The typography is a primary visual element and must not be reduced merely to make room for the 3D artwork.
- The right-side artwork is the visual counterweight; preserve clear separation from the title.
- Current approved CSS direction lives in `app/hero.css` under `HERO TYPOGRAPHY — approved BZABIK.ART direction`.
